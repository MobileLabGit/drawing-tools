(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["fr-DZ"] = {
            name: "fr-DZ",
            numberFormat: {
                pattern: ["-n"],
                decimals: 2,
                ",": " ",
                ".": ",",
                groupSize: [3],
                percent: {
                    pattern: ["-n %","n %"],
                    decimals: 2,
                    ",": " ",
                    ".": ",",
                    groupSize: [3],
                    symbol: "%"
                },
                currency: {
                    name: "Algerian Dinar",
                    abbr: "DZD",
                    pattern: ["-n $","n $"],
                    decimals: 2,
                    ",": " ",
                    ".": ",",
                    groupSize: [3],
                    symbol: "DA"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["dimanche","lundi","mardi","mercredi","jeudi","vendredi","samedi"],
                        namesAbbr: ["dim.","lun.","mar.","mer.","jeu.","ven.","sam."],
                        namesShort: ["di","lu","ma","me","je","ve","sa"]
                    },
                    months: {
                        names: ["janvier","février","mars","avril","mai","juin","juillet","août","septembre","octobre","novembre","décembre"],
                        namesAbbr: ["janv.","févr.","mars","avr.","mai","juin","juil.","août","sept.","oct.","nov.","déc."]
                    },
                    AM: ["AM","am","AM"],
                    PM: ["PM","pm","PM"],
                    patterns: {
                        d: "dd/MM/yyyy",
                        D: "dddd d MMMM yyyy",
                        F: "dddd d MMMM yyyy h:mm:ss tt",
                        g: "dd/MM/yyyy h:mm tt",
                        G: "dd/MM/yyyy h:mm:ss tt",
                        m: "d MMMM",
                        M: "d MMMM",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "h:mm tt",
                        T: "h:mm:ss tt",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM yyyy",
                        Y: "MMMM yyyy"
                    },
                    "/": "/",
                    ":": ":",
                    firstDay: 6
                }
            }
        };
    })();

}));

(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["ar-SA"] = {
            name: "ar-SA",
            numberFormat: {
                pattern: ["-n"],
                decimals: 2,
                ",": ",",
                ".": ".",
                groupSize: [3],
                percent: {
                    pattern: ["-n %","n %"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3],
                    symbol: "%"
                },
                currency: {
                    name: "Saudi Riyal",
                    abbr: "SAR",
                    pattern: ["-n $","n $"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3],
                    symbol: "ر.س.‏"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"],
                        namesAbbr: ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"],
                        namesShort: ["ح","ن","ث","ر","خ","ج","س"]
                    },
                    months: {
                        names: ["محرم","صفر","ربيع الأول","ربيع الثاني","جمادى الأولى","جمادى الثانية","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"],
                        namesAbbr: ["محرم","صفر","ربيع الأول","ربيع الثاني","جمادى الأولى","جمادى الثانية","رجب","شعبان","رمضان","شوال","ذو القعدة","ذو الحجة"]
                    },
                    AM: ["ص","ص","ص"],
                    PM: ["م","م","م"],
                    patterns: {
                        d: "dd/MM/yy",
                        D: "dd/MMMM/yyyy",
                        F: "dd/MMMM/yyyy hh:mm:ss tt",
                        g: "dd/MM/yy hh:mm tt",
                        G: "dd/MM/yy hh:mm:ss tt",
                        m: "dd MMMM",
                        M: "dd MMMM",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "hh:mm tt",
                        T: "hh:mm:ss tt",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM, yyyy",
                        Y: "MMMM, yyyy"
                    },
                    "/": "/",
                    ":": ":",
                    firstDay: 0
                }
            }
        };
    })();

}));

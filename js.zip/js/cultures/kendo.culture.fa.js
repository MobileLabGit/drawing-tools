(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["fa"] = {
            name: "fa",
            numberFormat: {
                pattern: ["n-"],
                decimals: 2,
                ",": ",",
                ".": "/",
                groupSize: [3],
                percent: {
                    pattern: ["n- %","n %"],
                    decimals: 2,
                    ",": ",",
                    ".": "/",
                    groupSize: [3],
                    symbol: "%"
                },
                currency: {
                    name: "",
                    abbr: "",
                    pattern: ["n-$","n$"],
                    decimals: 2,
                    ",": ",",
                    ".": "/",
                    groupSize: [3],
                    symbol: "ريال"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["يكشنبه","دوشنبه","سه شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"],
                        namesAbbr: ["يكشنبه","دوشنبه","سه شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه"],
                        namesShort: ["ی","د","س","چ","پ","ج","ش"]
                    },
                    months: {
                        names: ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"],
                        namesAbbr: ["فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"]
                    },
                    AM: ["ق.ظ","ق.ظ","ق.ظ"],
                    PM: ["ب.ظ","ب.ظ","ب.ظ"],
                    patterns: {
                        d: "dd/MM/yyyy",
                        D: "dddd, d MMMM yyyy",
                        F: "dddd, d MMMM yyyy hh:mm:ss tt",
                        g: "dd/MM/yyyy hh:mm tt",
                        G: "dd/MM/yyyy hh:mm:ss tt",
                        m: "d MMMM",
                        M: "d MMMM",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "hh:mm tt",
                        T: "hh:mm:ss tt",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM, yyyy",
                        Y: "MMMM, yyyy"
                    },
                    "/": "/",
                    ":": ":",
                    firstDay: 6
                }
            }
        };
    })();

}));

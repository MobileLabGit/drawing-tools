(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["ky-KG"] = {
            name: "ky-KG",
            numberFormat: {
                pattern: ["-n"],
                decimals: 2,
                ",": " ",
                ".": ",",
                groupSize: [3],
                percent: {
                    pattern: ["-n%","n%"],
                    decimals: 2,
                    ",": " ",
                    ".": ",",
                    groupSize: [3],
                    symbol: "%"
                },
                currency: {
                    name: "Kyrgystani Som",
                    abbr: "KGS",
                    pattern: ["-n $","n $"],
                    decimals: 2,
                    ",": " ",
                    ".": ",",
                    groupSize: [3],
                    symbol: "сом"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["жекшемби","дүйшөмбү","шейшемби","шаршемби","бейшемби","жума","ишемби"],
                        namesAbbr: ["Жш","Дш","Шш","Шр","Бш","Жм","Иш"],
                        namesShort: ["Жш","Дш","Шш","Шр","Бш","Жм","Иш"]
                    },
                    months: {
                        names: ["Январь","Февраль","Март","Апрель","Май","Июнь","Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь"],
                        namesAbbr: ["янв","фев","мар","апр","май","июн","июл","авг","сен","окт","ноя","дек"]
                    },
                    AM: [""],
                    PM: [""],
                    patterns: {
                        d: "d-MMM yy",
                        D: "dd-MMMM yyyy'-ж.'",
                        F: "dd-MMMM yyyy'-ж.' HH:mm:ss",
                        g: "d-MMM yy HH:mm",
                        G: "d-MMM yy HH:mm:ss",
                        m: "d-MMMM",
                        M: "d-MMMM",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "HH:mm",
                        T: "HH:mm:ss",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM yyyy'-ж.'",
                        Y: "MMMM yyyy'-ж.'"
                    },
                    "/": "-",
                    ":": ":",
                    firstDay: 1
                }
            }
        };
    })();

}));

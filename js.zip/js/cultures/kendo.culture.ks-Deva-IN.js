(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["ks-Deva-IN"] = {
            name: "ks-Deva-IN",
            numberFormat: {
                pattern: ["-n"],
                decimals: 2,
                ",": ",",
                ".": ".",
                groupSize: [3,2],
                percent: {
                    pattern: ["-n %","n%"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3,2],
                    symbol: "%"
                },
                currency: {
                    name: "Indian Rupee",
                    abbr: "INR",
                    pattern: ["$ -n","$ n"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3,2],
                    symbol: "₹"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
                        namesAbbr: ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
                        namesShort: ["Su","Mo","Tu","We","Th","Fr","Sa"]
                    },
                    months: {
                        names: ["January","February","March","April","May","June","July","August","September","October","November","December"],
                        namesAbbr: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
                    },
                    AM: ["AM","am","AM"],
                    PM: ["PM","pm","PM"],
                    patterns: {
                        d: "dd-MM-yyyy",
                        D: "dddd, MMMM dd, yyyy",
                        F: "dddd, MMMM dd, yyyy HH:mm:ss",
                        g: "dd-MM-yyyy H:mm",
                        G: "dd-MM-yyyy HH:mm:ss",
                        m: "d MMMM",
                        M: "d MMMM",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "H:mm",
                        T: "HH:mm:ss",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM, yyyy",
                        Y: "MMMM, yyyy"
                    },
                    "/": "-",
                    ":": ":",
                    firstDay: 1
                }
            }
        };
    })();

}));

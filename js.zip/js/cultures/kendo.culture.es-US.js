(function (factory) {
    typeof define === 'function' && define.amd ? define(['kendo.core'], factory) :
    factory();
})((function () {
    (function( window, undefined$1 ) {
        kendo.cultures["es-US"] = {
            name: "es-US",
            numberFormat: {
                pattern: ["-n"],
                decimals: 2,
                ",": ",",
                ".": ".",
                groupSize: [3],
                percent: {
                    pattern: ["-n%","n%"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3],
                    symbol: "%"
                },
                currency: {
                    name: "US Dollar",
                    abbr: "USD",
                    pattern: ["($n)","$n"],
                    decimals: 2,
                    ",": ",",
                    ".": ".",
                    groupSize: [3],
                    symbol: "$"
                }
            },
            calendars: {
                standard: {
                    days: {
                        names: ["domingo","lunes","martes","miércoles","jueves","viernes","sábado"],
                        namesAbbr: ["dom","lun","mar","mié","jue","vie","sáb"],
                        namesShort: ["do","lu","ma","mi","ju","vi","sa"]
                    },
                    months: {
                        names: ["enero","febrero","marzo","abril","mayo","junio","julio","agosto","septiembre","octubre","noviembre","diciembre"],
                        namesAbbr: ["ene","feb","mar","abr","may","jun","jul","ago","sep","oct","nov","dic"]
                    },
                    AM: ["AM","am","AM"],
                    PM: ["PM","pm","PM"],
                    patterns: {
                        d: "M/d/yyyy",
                        D: "dddd, MMMM dd, yyyy",
                        F: "dddd, MMMM dd, yyyy h:mm:ss tt",
                        g: "M/d/yyyy h:mm tt",
                        G: "M/d/yyyy h:mm:ss tt",
                        m: "MMMM d",
                        M: "MMMM d",
                        s: "yyyy'-'MM'-'dd'T'HH':'mm':'ss",
                        t: "h:mm tt",
                        T: "h:mm:ss tt",
                        u: "yyyy'-'MM'-'dd HH':'mm':'ss'Z'",
                        y: "MMMM' de 'yyyy",
                        Y: "MMMM' de 'yyyy"
                    },
                    "/": "/",
                    ":": ":",
                    firstDay: 0
                }
            }
        };
    })();

}));

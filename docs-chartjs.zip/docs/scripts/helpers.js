// Add helpers needed in samples here.
// Usable through `helpers[name]`.
export {color, getHoverColor, easingEffects} from '../../dist/helpers.js';

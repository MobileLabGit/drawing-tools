---
title: Server Operations
page_title: jQuery FileManager Documentation - Server Operations in FileManager
description: "Get understanding in the Server Operations in FileManager."
slug: serveroperations_kendoui_filemanager_widget
published: false
position: 3
---

# Server Operations
